﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using DrawCircle;

namespace DrawCircleTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_5_or_7_return()
        {
            double radius1 = 5;
            double radius2 = 7;

            // Act
            double area1 = Math.PI * Math.Pow(radius1,2);
            double area2 = Math.PI * Math.Pow(radius2,2);

            // Assert
            Assert.AreEqual(area1, Circle.CalculateArea(radius1));
            Assert.AreEqual(area2, Circle.CalculateArea(radius2));
        }
    }
}
