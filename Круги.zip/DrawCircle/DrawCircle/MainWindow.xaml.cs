﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DrawCircle
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public void DrawCircles(double radius1, double radius2)
        {
           CircleCanvas.Children.Clear();
            double circle1Area = Circle.CalculateArea(radius1);
            double circle2Area = Circle.CalculateArea(radius2);
            // Рисуем первую окружность
            Ellipse circle1 = new Ellipse
            {
                Width = radius1,
                Height = radius1,
                Fill = Brushes.Blue,
                Stroke = Brushes.White,
                StrokeThickness = 1
            };
            Canvas.SetLeft(circle1, 50);
            Canvas.SetTop(circle1, 50);
            CircleCanvas.Children.Add(circle1);

            // Рисуем вторую окружность
            Ellipse circle2 = new Ellipse
            {
                Width = radius2,
                Height = radius2,
                Fill = Brushes.Red,
                Stroke = Brushes.White,
                StrokeThickness = 1
            };
            Canvas.SetLeft(circle2, 50);
            Canvas.SetTop(circle2, 200);
            CircleCanvas.Children.Add(circle2);

           if(circle1Area>circle2Area)
            {
                ResultTextBlock.Text = $"Площадь окружности 1: {circle1Area:F2} усл. ед.\nПлощадь окружности 2: {circle2Area:F2} усл. ед.\n Площадь окружности 1 больше";
            }
            if (circle2Area > circle1Area)
            {
                ResultTextBlock.Text = $"Площадь окружности 1: {circle1Area:F2} усл. ед.\nПлощадь окружности 2: {circle2Area:F2} усл. ед. \n Площадь окружности 2 больше";
            }
            if (circle2Area == circle1Area && circle1Area == circle2Area)
            {
                ResultTextBlock.Text = $"Площадь окружности 1: {circle1Area:F2} усл. ед.\nПлощадь окружности 2: {circle2Area:F2} усл. ед. \n Площади равны";
            }
        }

        private void CompareCirclesButton_Click(object sender, RoutedEventArgs e)
        {
       
            if (double.TryParse(Radius1TextBox.Text, out double radius1) && double.TryParse(Radius2TextBox.Text, out double radius2))
            {
             DrawCircles(radius1, radius2);
            }
            else
            {
                MessageBox.Show("Введите числовые значения радиусов.");
            }
        }
    }
}
