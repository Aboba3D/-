﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Films;

namespace FilmsTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_900_flames()
        {
            MovieViewer movieViewer = new MovieViewer();

            bool enoughTime = movieViewer.CheckIfEnoughTimeForMovie(900); 

            Assert.IsTrue(enoughTime);
        }
    }
}
