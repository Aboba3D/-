﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Films
{
    public class MovieViewer
    {
        public int Frames { get; set; }

        public bool CheckIfEnoughTimeForMovie(int frames)
        {
            int seconds = frames / 25;
            if (seconds <= 3600) 
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
