﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Bank;

namespace BankTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_10000_4_2500_1000()
        {
            SalaryCalculator calculator = new SalaryCalculator()
            {
                TotalAmount = 10000,
                NumberOfEmployees = 4,
                AverageSalary = 2500,
                BalanceInCash = 1000
            };
            bool result = calculator.CanPaySalaries();

            Assert.IsTrue(result);
        }

    }
}

