﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    public class SalaryCalculator
    {
    public double TotalAmount { get; set; } // Сумма денег из банка
    public int NumberOfEmployees { get; set; } // Количество работников
    public double AverageSalary { get; set; } // Средняя зарплата работника
    public double BalanceInCash { get; set; } // Остаток в кассе

    public double CalculateTotalSalary()
    {
        return NumberOfEmployees * AverageSalary;
    }

    public bool CanPaySalaries()
    {
        double totalSalary = CalculateTotalSalary();
        return (totalSalary <= TotalAmount + BalanceInCash);
    }
    }
}
