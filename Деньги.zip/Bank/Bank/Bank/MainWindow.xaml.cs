﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Bank
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void CheckSalary_Click(object sender, RoutedEventArgs e)
        {
            SalaryCalculator calculator = new SalaryCalculator()
            {
                TotalAmount = double.Parse(txtTotalAmount.Text),
                NumberOfEmployees = int.Parse(txtNumberOfEmployees.Text),
                AverageSalary = double.Parse(txtAverageSalary.Text),
                BalanceInCash = double.Parse(txtBalanceInCash.Text)
            };

            bool canPaySalaries = calculator.CanPaySalaries();

            if (canPaySalaries)
            {
                Answer.Content = "Хватает";
            }
            else
            {
                Answer.Content = "Не хватает";
            }
        }
    }
}
