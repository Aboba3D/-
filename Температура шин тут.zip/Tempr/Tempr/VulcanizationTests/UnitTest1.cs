﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Tempr;

namespace VulcanizationTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_75_or_55()
        {

            Vulcanization vulcanization = new Vulcanization(75, 55);

            bool result = vulcanization.IsVulcanizationSuccessful();

            Assert.IsTrue(result);
        }
     
    }
}
