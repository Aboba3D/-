﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tempr
{
    public class Vulcanization
    {
        public int Temperature { get; set; }
        public int Duration { get; set; }

        public Vulcanization(int temperature, int duration)
        {
            Temperature = temperature;
            Duration = duration;
        }

        public bool IsVulcanizationSuccessful()
        {
            return Temperature >= 70 && Temperature <= 80 && Duration >= 50 && Duration <= 60;
        }
    }
}
