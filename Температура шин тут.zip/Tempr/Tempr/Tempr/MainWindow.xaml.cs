﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Tempr;

namespace Tempr
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void StartVulcanization_Click(object sender, RoutedEventArgs e)
        {
            int temperature = int.Parse(temperatureTextBox.Text);
            int duration = int.Parse(durationTextBox.Text);

            Vulcanization vulcanization = new Vulcanization(temperature, duration);

            if (vulcanization.IsVulcanizationSuccessful())
            {
                resultLabel.Content = "Успех";
            }
            else
            {
                resultLabel.Content = "Провал";
            }
        }
    }
}
