﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Puls;

namespace PulsTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_60_80_120()
        {
            AstronautCandidate candidate1 = new AstronautCandidate(60, 80, 120);
            Assert.IsTrue(candidate1.IsFitForCosmonautSchool());
        }
    }
}
