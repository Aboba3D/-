﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Puls
{
   public class AstronautCandidate
    
   {
        public int Pulse { get; set; }
        public int SystolicPressure { get; set; }
        public int DiastolicPressure { get; set; }

        private int pulse;
        private int lowerPressure;
        private int upperPressure;

        public AstronautCandidate(int pulse, int lowerPressure, int upperPressure)
        {
            this.pulse = pulse;
            this.lowerPressure = lowerPressure;
            this.upperPressure = upperPressure;
        }

        public bool IsFitForCosmonautSchool()
        {
            if (pulse >= 59 
                && pulse <= 63 
                && lowerPressure >= 77 
                && lowerPressure <= 83 
                && upperPressure >= 115 
                && upperPressure <= 125)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
