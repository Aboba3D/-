﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Flowers;

namespace FlowersTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_10_5_50_29()
        {
            FlowersShop flowerShop = new FlowersShop(10, 5, 50, 29);

            string revenue = flowerShop.CalculateRevenue();

            Assert.AreEqual("Роз больше", revenue);
        }
    }
}
