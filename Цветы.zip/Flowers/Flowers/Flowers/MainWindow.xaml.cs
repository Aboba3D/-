﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Flowers
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CalculateRevenue_Click(object sender, RoutedEventArgs e)
        {
            int rosesSold = int.Parse(rosesTextBox.Text);
            int rosePrice = int.Parse(rosePriceTextBox.Text);
            int tulipsSold = int.Parse(tulipsTextBox.Text);
            int tulipPrice = int.Parse(tulipPriceTextBox.Text);

            FlowersShop flowerShop = new FlowersShop(rosesSold, tulipsSold, rosePrice, tulipPrice);
            string revenue = flowerShop.CalculateRevenue();

            resultText.Text = $"{revenue}";
        }
    }
}

