﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flowers
{
    public class FlowersShop
    {
        public int RosesSold { get; set; }
        public int TulipsSold { get; set; }
        public int PricePerRose { get; set; }
        public int PricePerTulip { get; set; }

        public FlowersShop(int rosesSold, int tulipsSold, int pricePerRose, int pricePerTulip)
        {
            RosesSold = rosesSold;
            TulipsSold = tulipsSold;
            PricePerRose = pricePerRose;
            PricePerTulip = pricePerTulip;
        }

        public string CalculateRevenue()
        {
            int totalRevenueFromRoses = RosesSold * PricePerRose;
            int totalRevenueFromTulips = TulipsSold * PricePerTulip;

            if (totalRevenueFromRoses > totalRevenueFromTulips)
            {
                return "Роз больше";
            }
            else if (totalRevenueFromTulips > totalRevenueFromRoses)
            {
                return "Тюльпанов больше";
            }
            else
            {
                return totalRevenueFromRoses > totalRevenueFromTulips ? totalRevenueFromRoses.ToString() : totalRevenueFromTulips.ToString();
            }
        }
    }
}
