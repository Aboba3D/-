package com.example.shop

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import org.w3c.dom.Text

class ActivityZakaz : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zakaz)
        //Показ картинок
        val imageViewMilk: ImageView = findViewById(R.id.imageViewMilk)
        imageViewMilk.setImageResource(R.drawable.popo)
        val imageViewWater: ImageView = findViewById(R.id.imageViewWater)
        imageViewWater.setImageResource(R.drawable.zippo)
        val imageViewBread: ImageView = findViewById(R.id.imageViewBread)
        imageViewBread.setImageResource(R.drawable.dopo)
        val imageViewTea: ImageView = findViewById(R.id.imageViewTea)
        imageViewTea.setImageResource(R.drawable.opo)
        //ввод переменных
        var summa = 0
        var counter = 0
        var a = 0
        var b = 0
        var c = 0
        var d = 0
        //перменные циклы
        var aa=0
        var bb = 0
        var cc=0
        var dd=0
            //Появление кнопок
        val button_feet: Button = findViewById(R.id.button_feet1)
        val button_feet1: Button = findViewById(R.id.button_feet2)
        val button_feet2: Button = findViewById(R.id.button_feet3)
        val button_feet3: Button = findViewById(R.id.button_feet4)
        val buttonClear: Button = findViewById(R.id.buttonClear)
        val buttonBuy: Button = findViewById(R.id.buttonBuy)
        val textViewConclusion: TextView = findViewById(R.id.textViewConclusion)
        val textViewItogo: TextView = findViewById(R.id.textViewItogo)
//Кнопки выбора товара
        button_feet.setOnClickListener{
            if(a < 100) {
                val newText = "Adidas BlackStar = 3200"
                textViewConclusion.append(newText + "\n")
                summa += 3200
                textViewItogo.text = "Итого: " + summa + " Руб"
                aa = a
                a++
            }
        }
        button_feet1.setOnClickListener{
            if(b<100) {
                val newText = "Nike 360  = 4400 руб"
                textViewConclusion.append(newText + "\n")
                summa += 4400
                textViewItogo.text = "Итого: " + summa + " Руб"
                bb = b
                b++
            }
        }
        button_feet2.setOnClickListener{
            if(c<100) {
                val newText = "XPulse one = 3500 руб"
                textViewConclusion.append(newText + "\n")
                summa += 3500
                textViewItogo.text = "Итого: " + summa + " Руб"
                cc=c
                c++
            }

        }
        button_feet3.setOnClickListener{
            if (d<100) {
                val newText = "Nike abibas = 45000 руб"
                textViewConclusion.append(newText + "\n")
                summa += 45000
                textViewItogo.text = "Итого: " + summa + " Руб"
                dd=d
                d++
            }
        }
        //кнопка очищения
        buttonClear.setOnClickListener{
             summa = 0
            textViewConclusion.text=""
            textViewItogo.text="Итого:"
        }
        buttonBuy.setOnClickListener{
            // переход на другое активити
            val intent = Intent(this@ActivityZakaz, ActivityPlusMinus::class.java)
            intent.putExtra("summa",summa)
            intent.putExtra("KolMoloko",aa)
            intent.putExtra("KolHleb",bb)
            intent.putExtra("KolVoda",cc)
            intent.putExtra("KolChai",dd)
            //активизация перехода
            startActivity(intent)
        }

    }
}