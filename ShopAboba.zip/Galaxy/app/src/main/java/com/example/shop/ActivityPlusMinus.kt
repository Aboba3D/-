package com.example.shop

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import org.w3c.dom.Text

class ActivityPlusMinus : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plus_minus)

        var receivedSumma= intent.getIntExtra("summa",0)
        val kolmoloko= intent.getIntExtra("KolMoloko",0)
        val kolhleb= intent.getIntExtra("KolHleb",0)
        val kolvoda= intent.getIntExtra("KolVoda",0)
        val kolchai= intent.getIntExtra("KolChai",0)
        var km: Int=kolmoloko
        var kh: Int=kolhleb
        var kv: Int=kolvoda
        var kc: Int=kolchai
        //Показ картинок
        val imageViewMilk: ImageView = findViewById(R.id.imageViewMilk)
        imageViewMilk.setImageResource(R.drawable.popo)
        val imageViewWater: ImageView = findViewById(R.id.imageViewWater)
        imageViewWater.setImageResource(R.drawable.zippo)
        val imageViewBread: ImageView = findViewById(R.id.imageViewBread)
        imageViewBread.setImageResource(R.drawable.dopo)
        val imageViewTea: ImageView = findViewById(R.id.imageViewTea)
        imageViewTea.setImageResource(R.drawable.opo)

        //Появление кнопок и textview
        val buttonPlusMoloko: Button = findViewById(R.id.buttonPlusMoloko)
        val buttonMinusMoloko: Button = findViewById(R.id.buttonMinusMoloko)
        val buttonPlusHleb: Button = findViewById(R.id.buttonPlusHleb)
        val buttonMinusHleb: Button = findViewById(R.id.buttonMinusHleb)
        val buttonPlusVoda: Button = findViewById(R.id.buttonPlusVoda)
        val buttonMinusVoda: Button = findViewById(R.id.buttonMinusVoda)
        val buttonPlusChai: Button = findViewById(R.id.buttonPlusChai)
        val buttonMinusChai: Button = findViewById(R.id.buttonMinusChai)
        val buttonBack: Button = findViewById(R.id.buttonBack)
        val textViewItogogo: TextView = findViewById(R.id.textViewItogogo)
        val textViewMolochko: TextView=findViewById(R.id.textViewMolochko)
        val textViewHlebushek: TextView=findViewById(R.id.textViewHlebushek)
        val textViewVodichka: TextView=findViewById(R.id.textViewVodichka)
        val textViewChaik: TextView=findViewById(R.id.textViewChaik)
        textViewItogogo.text="Итого: "+ receivedSumma +" Руб"
        //Плюс и минус молоко
        buttonPlusMoloko.setOnClickListener{
            if (km>=0) {
                receivedSumma += 3200
                buttonMinusMoloko.isEnabled = true
            }
            km+=1
            textViewMolochko.setText("Adidas BlackStar ${km}")
            textViewItogogo.text = "Итого: " + receivedSumma + " Руб"
            Toast.makeText(this, "Adidas BlackStar ${km} шт.", Toast.LENGTH_SHORT).show()

        }
        buttonMinusMoloko.setOnClickListener{
            if (km>0) {
                receivedSumma -= 3200
            }
            km-=1
            if (km<0)
            {
                buttonMinusMoloko.isEnabled = false
                km=0
                textViewMolochko.setText("")
                return@setOnClickListener
            }
            textViewItogogo.text = "Итого: " + receivedSumma + " Руб"
            Toast.makeText(this, "Adidas BlackStar ${km} шт.", Toast.LENGTH_SHORT).show()
            textViewMolochko.setText("Молоко гост ${km}")


        }
        //Плюс и минус хлеб
        buttonPlusHleb.setOnClickListener{
            if(kh>=0) {
                receivedSumma += 4400

                buttonMinusHleb.isEnabled = true
            }
            kh+=1
            Toast.makeText(this, "Nike 360${kh} шт.", Toast.LENGTH_SHORT).show()
            textViewHlebushek.setText("Nike 360${kh}")
            textViewItogogo.text = "Итого: " + receivedSumma + " Руб"
        }
        buttonMinusHleb.setOnClickListener{
            if (kh>0) {
                receivedSumma -= 4400
            }
            kh-=1
            if (kh<0)
            {
                buttonMinusHleb.isEnabled = false
                kh=0
                textViewHlebushek.setText("")
                return@setOnClickListener
            }
            textViewItogogo.text = "Итого: " + receivedSumma + " Руб"
            Toast.makeText(this, "Nike 360 ${kh} шт.", Toast.LENGTH_SHORT).show()
            textViewHlebushek.setText("Nike 360 ${kh}")
        }
        //Плюс и минус вода
        buttonPlusVoda.setOnClickListener{
            if(kv>=0) {
                receivedSumma += 3500

                buttonMinusVoda.isEnabled = true
            }
            kv+=1
            Toast.makeText(this, "XPulse one ${kv} шт.", Toast.LENGTH_SHORT).show()
            textViewVodichka.setText("XPulse one ${kv}")
            textViewItogogo.text = "Итого: " + receivedSumma + " Руб"
        }
        buttonMinusVoda.setOnClickListener{
            if (kv>0) {
                receivedSumma -= 3500
            }
            kv-=1
            if (kv<0)
            {
                buttonMinusVoda.isEnabled = false
                kv=0
                textViewVodichka.setText("")
                return@setOnClickListener
            }
            textViewItogogo.text = "Итого: " + receivedSumma + " Руб"
            Toast.makeText(this, "XPulse one ${kv} шт.", Toast.LENGTH_SHORT).show()
            textViewVodichka.setText("XPulse one${kv}")
        }
        //Плюс и минус чай
        buttonPlusChai.setOnClickListener{
            if(kc>=0) {
                receivedSumma += 45000

                buttonMinusChai.isEnabled = true
            }
            kc+=1
            Toast.makeText(this, "Nike abibas ${kc} шт.", Toast.LENGTH_SHORT).show()
            textViewChaik.setText("Nike abibas ${kc}")
            textViewItogogo.text = "Итого: " + receivedSumma + " Руб"

        }
        buttonMinusChai.setOnClickListener{
            if (kc>0) {
                receivedSumma -= 45000
            }
            kc-=1
            if (kc<0)
            {
                buttonMinusChai.isEnabled = false
                kc=0
                textViewChaik.setText("")
                return@setOnClickListener
            }
            textViewItogogo.text = "Итого: " + receivedSumma + " Руб"
            Toast.makeText(this, "Nike abibas ${kc} шт.", Toast.LENGTH_SHORT).show()
            textViewChaik.setText("Nike abibas ${kc}")
        }

            //Кнопка возвращения
        buttonBack.setOnClickListener{
            // переход на другое активити
            val intent = Intent(this@ActivityPlusMinus, ActivityZakaz::class.java)
            //активизация перехода
            startActivity(intent)
        }

    }

}